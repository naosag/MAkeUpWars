import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Lip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lip extends Items
{
    public Lip(){
        puntos = 30;
    }
    
    /**
     * Act - do whatever the Lip wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        super.act();
    }    
}
