import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sofa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sofa extends Obstaculo
{
    /**
     * Act - do whatever the Sofa wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
