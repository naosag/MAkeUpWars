import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    int start = 1;
    int move = 12;
    int animation = 0;
    private GreenfootImage AtrP1;
    private GreenfootImage AtrP2;
    private GreenfootImage AtrP3;
    private GreenfootImage AtrP4;
    private GreenfootImage DerP1;
    private GreenfootImage DerP2;
    private GreenfootImage DerP3;
    private GreenfootImage DerP4;
    private GreenfootImage FrenteP1;
    private GreenfootImage FrenteP2;
    private GreenfootImage FrenteP3;
    private GreenfootImage FrenteP4;
    private GreenfootImage IzqP1;
    private GreenfootImage IzqP2;
    private GreenfootImage IzqP3;
    private GreenfootImage IzqP4;
    Balas bala;
    
    public Player(){
        AtrP1 = new GreenfootImage("AtrP1.png");
        AtrP2 = new GreenfootImage("AtrP2.png");
        AtrP3 = new GreenfootImage("AtrP3.png");
        
        DerP1 = new GreenfootImage("DerP1.png");
        DerP2 = new GreenfootImage("DerP2.png");
        DerP3 = new GreenfootImage("DerP3.png");
        
        FrenteP1 = new GreenfootImage("FrenteP1.png");
        FrenteP2 = new GreenfootImage("FrenteP2.png");
        FrenteP3 = new GreenfootImage("FrenteP3.png");
        
        IzqP1 = new GreenfootImage("IzqP1.png");
        IzqP2 = new GreenfootImage("IzqP2.png");
        IzqP3 = new GreenfootImage("IzqP3.png"); 
        
        bala = new Balas();        
        
    }
    
    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        int flag = 0;
        animation++;
        flag = leerTeclado();        
        fire(flag);
        
    }  
    
        public int leerTeclado(){
        int flagM =0;
         if(Greenfoot.isKeyDown("w")){
             flagM = 1;
             movecheck(flagM);
             return 1;
             
            }else if (Greenfoot.isKeyDown("s")){
             flagM = 2;
             movecheck(flagM);
             return 2;
             
            }else if (Greenfoot.isKeyDown("a")){               
                flagM = 3;
                movecheck(flagM);
                return 3;
                
            }else if (Greenfoot.isKeyDown("d")){
             flagM = 4;
             movecheck(flagM); 
              return 4;
             
       }
       else {
        return 0;
        }
       
       //checkTouch(flag);
    }
    
    public void movecheck(int flagM){
        if(animation % 4 == 0){
            
            if(flagM == 1)
                moveup();
            if(flagM == 2)
                movedown();
            if(flagM == 3)
                moveleft();
            if(flagM == 4)
                moveright();
        }
        
    }
    
    public void moveright(){
        setLocation(getX() + move, getY());     
         aniRight();
    }
    
    public void aniRight(){
        
            if(start == 1)
            setImage(DerP1);
        else if(start == 2)
            setImage(DerP2);
          else if(start == 3){
            setImage(DerP3);
            start = 1;
            return;
        }
        start++;
    }
    
    public void moveleft(){
        setLocation(getX() - move, getY());     
         aniLeft();
    }
    
    public void aniLeft(){
           if(start == 1)
            setImage(IzqP1);
        else if(start == 2)
            setImage(IzqP2);
          else if(start == 3){
            setImage(IzqP3);
            start = 1;
            return;
        }
        start++;
    }
    
    public void moveup(){
        setLocation(getX(), getY() - move ); 
        aniUp();
    }
    
    public void aniUp(){
            if(start == 1)
            setImage(AtrP1);
        else if(start == 2)
            setImage(AtrP2);
          else if(start == 3){
            setImage(AtrP3);
            start = 1;
            return;
        }
        start++;
    }
    
    
    public void movedown(){
        setLocation(getX(), getY() + move );     
            aniDown();
    }
    
    public void aniDown(){
            if(start == 1)
            setImage(FrenteP1);
        else if(start == 2)
            setImage(FrenteP2);
          else if(start == 3){
            setImage(FrenteP3);
            start = 1;
            return;
        }
        start++;
    }  
    
    public void addScore(int puntos){
        MyWorld mw = (MyWorld)getWorld();
        if(puntos == 1)
         mw.cont.add(1);
        if(puntos == 5)
           mw.cont.add(5); 
        if(puntos == 30)
           mw.cont.add(30); 
    }
    
    public void fire(int flag){
        if(Greenfoot.isKeyDown("l")){
          MyWorld mw = (MyWorld)getWorld();
          mw.addObject(bala,0,0);
          bala.setLocation(getX()+5,getY()+5);
          bala.checkDirection(flag);
          //bala.setRotation(getRotation());
          
        
        }
    }
    
    /*public void checkTouch(int flag ){
        
        if(isTouching(Obstaculo.class)){
            if(flag == 1){
                setLocation(getX(), getY() + move/4 );
            }
            
            if(flag == 2){
                setLocation(getX(), getY() - move/4 );
            }
            
            if(flag == 3){
                setLocation(getX() + move/4, getY());
            }
            
            if(flag == 4){
                setLocation(getX() - move/4, getY());
            }
            
        }
        
    }*/
}
