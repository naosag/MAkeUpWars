import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    private boolean crear;
    private boolean item;
    private SimpleTimer timer;   
    private Counter timerDisplay;
    private Counter timerItem;
    Sofa sofa = new Sofa();
    Cama cama =new Cama();
    Desk desk= new Desk();
    Mesa mesa = new Mesa();
    Balas bala ;
    Esmalte esmalte;
    Lip lip = new Lip();
    Paleta paleta ;  
    Player player ;
    public Counter cont ;
    private A[] arrayEneA;    
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(890, 522, 1);
        timerDisplay = new Counter("Time: ");
        timer = new SimpleTimer();        
        timerItem = new Counter("Timeaslknfaj: ");
        cont = new Counter("Puntos: ");
        player = new Player();
        bala = new Balas();
        crear = true;
        item = true;      
        arrayEneA = new A[3];
        
        prepare(); 
    }
    
    public void prepare(){
        addObject(sofa,237,102); 
        addObject(cama,626,148);
        addObject(desk,825,330);
        addObject(mesa,109,465);
        addObject(player,445,266);
        addObject(cont , 51, 22);
        addObject(timerDisplay , 200 , 22);
        
        for(int x = 0; x < 3 ; x++){
            arrayEneA[x] = new A();
            int enemyX = 360;
            int enemyY = 500; 
            addObject(arrayEneA[x], enemyX, enemyY);                     
            
        }
    }
    
    public void act(){
        
        timerIni();
        checkTimer();
    }
    
    public void timerIni(){
        
         if(timer.millisElapsed() > 1000 ){
            crear = true;
            item = true;
            timerDisplay.add(1);
            timerItem.add(1);
            timer.mark();
        }
    
    }
    
    public void checkTimer(){
                
        if(timerItem.getValue() % 4 == 0 && crear == true && timerItem.getValue() != 0){            
            prepareE();
            crear = false;   
            
        }
        
        if(timerItem.getValue() % 30 == 0 && item == true  && timerItem.getValue() != 0){            
            prepareP();
            item = false;
        }

    }    
    
    public void prepareE(){
        int coorX = Greenfoot.getRandomNumber(850);
        int coorY = Greenfoot.getRandomNumber(460)+50;   
        
        if(crear == true){  
            esmalte   = new Esmalte();
            addObject(esmalte, coorX, coorY);
          
        }

    }
     
    public void prepareP(){
       int coorX = Greenfoot.getRandomNumber(850);
       int coorY = Greenfoot.getRandomNumber(460)+50; 
        
        
        if (item = true){
            paleta = new Paleta();
            addObject(paleta,coorX,coorY);
        }
        
        }
    
 }  