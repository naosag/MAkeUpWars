import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy extends Actor
{
    int steps = 5;
    int move = Greenfoot.getRandomNumber(40);
    /**
     * Act - do whatever the Enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        moveRandom(move);
        
    } 
    
    public void moveRandom(int move){
        
        if(move < 10 && move > 1 ) 
            moveup();  
        if(move > 10 && move < 20)
            movedown();
        if(move > 20 && move < 30)
            moveleft();
        if(move > 30 )   
            moveright();    
    
    }
    
    public void moveright(){
        setLocation(getX() + steps, getY());    
   
    }
    
     public void moveup(){
        setLocation(getX(), getY() + steps);    
   
    }
    
    public void moveleft(){
        setLocation(getX() - steps , getY());    
   
    }
    
    public void movedown(){
        setLocation(getX(), getY() - steps);    
   
    }
    
    
    
}
